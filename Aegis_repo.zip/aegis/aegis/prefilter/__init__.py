"""Aegis layer: prefilter."""
