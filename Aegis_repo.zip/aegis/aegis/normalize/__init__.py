"""Aegis layer: normalize."""
