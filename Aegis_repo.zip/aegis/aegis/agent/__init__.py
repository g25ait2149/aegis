"""Aegis layer: agent."""
