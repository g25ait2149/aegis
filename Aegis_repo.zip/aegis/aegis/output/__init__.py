"""Aegis layer: output."""
