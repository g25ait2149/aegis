"""Aegis layer: ops."""
