"""Aegis layer: guard."""
